para utilizar o programa corretamente siga os passos:

1- pip install -r requirements.txt
2 - Execute o arquivo download_nltk.py